package com.votera.app

import android.content.Context
import android.content.SharedPreferences
import com.google.gson.FieldNamingPolicy
import com.google.gson.GsonBuilder
import com.google.gson.JsonParser
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.OkHttpClient
import retrofit2.HttpException
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.PUT
import retrofit2.http.Path
import java.io.IOException
import java.util.concurrent.TimeUnit

// Default server address. Emulator: http://10.0.2.2:8000/ . Real phone: your laptop's Wi-Fi IP.
// It can also be changed on the login screen (Server settings) without rebuilding the app.
const val BASE_URL = "http://192.168.1.12:8000/"

/** Holds the server address the app talks to. The saved address on the phone overrides BASE_URL. */
object ServerConfig {
    private var prefs: SharedPreferences? = null
    @Volatile var baseUrl: String = BASE_URL
        private set

    fun init(context: Context) {
        val p = context.getSharedPreferences("votera_server", Context.MODE_PRIVATE)
        prefs = p
        p.getString("base_url", null)?.let { if (it.isNotBlank()) baseUrl = it }
    }

    /** Accepts "192.168.1.12", "192.168.1.12:8000", "http://192.168.1.12:8000" or an https address. Returns null if invalid. */
    fun normalize(raw: String): String? {
        var s = raw.trim()
        if (s.isEmpty()) return null
        if (!s.startsWith("http://", true) && !s.startsWith("https://", true)) s = "http://$s"
        val schemeEnd = s.indexOf("://") + 3
        val hostEnd = s.indexOf('/', schemeEnd).let { if (it == -1) s.length else it }
        val authority = s.substring(schemeEnd, hostEnd)
        // A bare IP address with no port gets the backend's default port.
        if (Regex("""\d{1,3}(\.\d{1,3}){3}""").matches(authority)) s = s.substring(0, hostEnd) + ":8000" + s.substring(hostEnd)
        if (!s.endsWith("/")) s += "/"
        return if (s.toHttpUrlOrNull() != null) s else null
    }

    fun save(url: String) {
        baseUrl = url
        prefs?.edit()?.putString("base_url", url)?.apply()
    }
}

object Session { @Volatile var token: String? = null }

// Field names are camelCase here and become snake_case in JSON (naming policy below).
// portal is "student" or "admin": which login screen was used. The server rejects a mismatch (RBAC).
data class LoginReq(val studentNumber: String, val password: String, val portal: String)
data class LoginRes(val otpToken: String, val devOtp: String)
data class OtpReq(val otpToken: String, val code: String)
data class UserDto(val studentNumber: String, val fullName: String, val program: String, val role: String)
data class TokenRes(val accessToken: String, val user: UserDto)
data class ElectionDto(val id: Int, val title: String, val status: String)
data class StatusReq(val status: String)
data class CandidateDto(
    val id: Int, val fullName: String, val program: String, val position: String,
    val manifesto: String, val achievements: String, val leadership: String, val community: String,
    val highestSimilarity: Double?, val originalityScore: Double?, val flagged: Boolean,
    val achievementsScore: Double?, val leadershipScore: Double?, val communityScore: Double?,
    val credibilityScore: Double?
)
data class ScoresReq(val achievementsScore: Double, val leadershipScore: Double, val communityScore: Double)
data class FlaggedRes(val threshold: Double, val flagged: List<CandidateDto>)
data class AnnouncementDto(val id: Int, val title: String, val body: String, val createdAt: String)
data class AnnouncementReq(val title: String, val body: String)
data class VoteStatusRes(val hasVoted: Boolean, val transactionId: String?)
data class VoteReq(val candidateId: Int)
data class VoteRes(val message: String, val transactionId: String)
data class TurnoutDto(val votesCast: Int, val eligibleVoters: Int, val turnoutPercent: Double)
data class ResultRowDto(val rank: Int, val candidateId: Int, val fullName: String, val votes: Int, val percent: Double)
data class ResultsRes(val election: ElectionDto, val turnout: TurnoutDto, val results: List<ResultRowDto>)

interface VoteraApi {
    @POST("auth/login") suspend fun login(@Body b: LoginReq): LoginRes
    @POST("auth/verify-otp") suspend fun verifyOtp(@Body b: OtpReq): TokenRes
    @GET("election") suspend fun election(): ElectionDto
    @PUT("admin/election/status") suspend fun setStatus(@Body b: StatusReq): ElectionDto
    @GET("candidates") suspend fun candidates(): List<CandidateDto>
    @PUT("admin/candidates/{id}/scores") suspend fun setScores(@Path("id") id: Int, @Body b: ScoresReq): CandidateDto
    @GET("admin/flagged") suspend fun flagged(): FlaggedRes
    @GET("announcements") suspend fun announcements(): List<AnnouncementDto>
    @POST("announcements") suspend fun postAnnouncement(@Body b: AnnouncementReq): AnnouncementDto
    @GET("vote/status") suspend fun voteStatus(): VoteStatusRes
    @POST("vote") suspend fun vote(@Body b: VoteReq): VoteRes
    @GET("results") suspend fun results(): ResultsRes
}

object Net {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .addInterceptor { chain ->  // attaches the JWT to every request
            val b = chain.request().newBuilder()
            Session.token?.let { b.header("Authorization", "Bearer $it") }
            chain.proceed(b.build())
        }.build()

    private var cachedUrl = ""
    private var cachedApi: VoteraApi? = null

    /** Rebuilt automatically whenever the server address changes. */
    val api: VoteraApi
        @Synchronized get() {
            val url = ServerConfig.baseUrl
            val existing = cachedApi
            if (existing != null && cachedUrl == url) return existing
            val gson = GsonBuilder().setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES).create()
            val built = Retrofit.Builder().baseUrl(url).client(client)
                .addConverterFactory(GsonConverterFactory.create(gson)).build()
                .create(VoteraApi::class.java)
            cachedApi = built
            cachedUrl = url
            return built
        }
}

/** Turns a failed call into a message a student can read (FastAPI sends {"detail": "..."}). */
fun errorMessage(t: Throwable): String = when (t) {
    is HttpException -> try {
        val body = t.response()?.errorBody()?.string().orEmpty()
        val d = JsonParser.parseString(body).asJsonObject.get("detail")
        if (d != null && d.isJsonPrimitive) d.asString else "Invalid input"
    } catch (e: Exception) { "Request failed (${t.code()})" }
    is IOException -> "Cannot reach the server at ${ServerConfig.baseUrl}. Check your connection and the server address."
    else -> t.message ?: "Something went wrong"
}
